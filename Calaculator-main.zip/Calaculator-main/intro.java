package project1;

public class intro {
	
	interface inter1{
		public void add(int a,int b);
		public void sub(int a,int b);
		public void mul(int a,int b);
		public void div(int a,int b);
	}
}
