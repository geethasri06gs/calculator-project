package project1;
import project1.intro;

public class intro2 implements intro.inter1 {
	int a;
	int b;
	public intro2()
	{
		
	}
	public intro2(int x){
		this.a=x;
	}
	
	public void add(int a,int b)
	{
		System.out.println("Keep the result of Addition in your mind = "+(a+b));
	}
	public void sub(int a,int b)
	{
	}
	public void mul(int a,int b)
	{
	}
	public void div(int a,int b)
	{
	}
}
